#include "Moto.h"

Moto::Moto()
{
    this->cantidadDeRuedas = 2;

}
void Moto::verificarTelepase(bool telepase)
{
    this->telepase = false;
}

float Moto::descuento()
{
    return 0;
}
